import React from 'react';
import { GraduationCap } from 'lucide-react';

const Learn = () => {
  return (
    <div className="min-h-screen bg-gray-50 p-8">
      <div className="mb-8">
        <h1 className="text-2xl font-bold text-gray-900 flex items-center gap-3">
          <GraduationCap className="w-8 h-8 text-indigo-600" />
          Learn
        </h1>
        <p className="text-gray-600 mt-1">Educational resources and financial tips</p>
      </div>
      
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
        <div className="bg-white p-6 rounded-2xl shadow-sm">
          <h2 className="text-lg font-semibold mb-4">Coming Soon</h2>
          <p className="text-gray-600">The learning center is under development. Check back soon!</p>
        </div>
      </div>
    </div>
  );
};

export default Learn;