import React from 'react';
import { useNavigate, useLocation } from 'react-router-dom';
import {
  LayoutDashboard,
  PiggyBank,
  LineChart,
  Wallet,
  GraduationCap,
  Settings,
  HelpCircle,
  Bell,
  Target,
  CreditCard,
  History,
  Sparkles,
} from 'lucide-react';

const Sidebar = () => {
  const navigate = useNavigate();
  const location = useLocation();

  const menuItems = [
    { icon: LayoutDashboard, label: 'Dashboard', path: '/dashboard' },
    { icon: PiggyBank, label: 'Budgeting', path: '/budgeting' },
    { icon: Target, label: 'Goals', path: '/goals' },
    { icon: LineChart, label: 'Investments', path: '/investments' },
    { icon: History, label: 'Transactions', path: '/transactions' },
    { icon: CreditCard, label: 'Cards', path: '/cards' },
    { icon: GraduationCap, label: 'Learn', path: '/learn' },
    { icon: Settings, label: 'Settings', path: '/settings' },
  ];

  return (
    <div className="w-72 bg-white h-screen border-r border-gray-200 flex flex-col">
      <div className="p-8">
        <h1 className="text-2xl font-bold text-indigo-600 flex items-center gap-3 cursor-pointer" onClick={() => navigate('/dashboard')}>
          <div className="w-10 h-10 bg-indigo-600 rounded-xl flex items-center justify-center">
            <Wallet className="w-6 h-6 text-white" />
          </div>
          FinanceAI
        </h1>
      </div>
      
      <nav className="flex-1 px-4">
        {menuItems.map((item) => (
          <button
            key={item.label}
            onClick={() => navigate(item.path)}
            className={`w-full flex items-center gap-3 px-4 py-3 rounded-xl text-left mb-1
              ${location.pathname === item.path
                ? 'bg-indigo-50 text-indigo-600 font-medium' 
                : 'text-gray-600 hover:bg-gray-50 hover:text-gray-900'
              } transition-colors`}
          >
            <item.icon className="w-5 h-5" />
            <span className="font-medium">{item.label}</span>
            {location.pathname === item.path && (
              <div className="ml-auto w-1.5 h-6 bg-indigo-600 rounded-full"></div>
            )}
          </button>
        ))}
      </nav>

      <div className="p-4 mx-4 mb-4 bg-gray-50 rounded-xl">
        <div className="flex items-center gap-3 mb-3">
          <div className="w-8 h-8 bg-indigo-100 rounded-lg flex items-center justify-center">
            <Sparkles className="w-4 h-4 text-indigo-600" />
          </div>
          <div>
            <h3 className="font-medium text-gray-900">Pro Features</h3>
            <p className="text-xs text-gray-500">Unlock premium features</p>
          </div>
        </div>
        <button className="w-full px-4 py-2 bg-indigo-600 text-white rounded-lg text-sm font-medium hover:bg-indigo-700 transition-colors">
          Upgrade Now
        </button>
      </div>

      <div className="p-4 border-t border-gray-200">
        <button className="w-full flex items-center gap-3 px-4 py-3 text-gray-600 hover:bg-gray-50 hover:text-gray-900 rounded-xl transition-colors">
          <HelpCircle className="w-5 h-5" />
          <span className="font-medium">Help & Support</span>
        </button>
      </div>
    </div>
  );
};

export default Sidebar;