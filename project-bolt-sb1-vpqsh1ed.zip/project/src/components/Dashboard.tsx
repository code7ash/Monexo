import React from 'react';
import {
  ArrowUpRight,
  ArrowDownRight,
  DollarSign,
  TrendingUp,
  Bell,
  Search,
  CreditCard,
  Sparkles,
  Target,
} from 'lucide-react';

export const Dashboard = () => {
  return (
    <div className="flex-1 min-h-screen bg-gray-50">
      {/* Header */}
      <header className="bg-white border-b border-gray-200 sticky top-0 z-10">
        <div className="flex items-center justify-between px-8 py-4">
          <div className="flex items-center gap-6">
            <div className="relative">
              <Search className="w-5 h-5 absolute left-3 top-1/2 transform -translate-y-1/2 text-gray-400" />
              <input
                type="text"
                placeholder="Search transactions..."
                className="pl-10 pr-4 py-2.5 border border-gray-200 rounded-xl w-72 focus:outline-none focus:ring-2 focus:ring-indigo-500 bg-gray-50"
              />
            </div>
            <nav className="flex items-center gap-1">
              <button className="px-4 py-2 text-sm font-medium text-gray-700 hover:text-indigo-600 hover:bg-indigo-50 rounded-lg transition-colors">Today</button>
              <button className="px-4 py-2 text-sm font-medium text-gray-700 hover:text-indigo-600 hover:bg-indigo-50 rounded-lg transition-colors">Week</button>
              <button className="px-4 py-2 text-sm font-medium text-white bg-indigo-600 rounded-lg transition-colors">Month</button>
            </nav>
          </div>
          <div className="flex items-center gap-6">
            <button className="p-2 relative">
              <Bell className="w-6 h-6 text-gray-600" />
              <span className="absolute top-1 right-1 w-2 h-2 bg-red-500 rounded-full"></span>
            </button>
            <div className="flex items-center gap-3">
              <img
                src="https://images.unsplash.com/photo-1472099645785-5658abf4ff4e?ixlib=rb-1.2.1&auto=format&fit=facearea&facepad=2&w=256&h=256&q=80"
                alt="Profile"
                className="w-10 h-10 rounded-full border-2 border-white shadow-sm"
              />
              <div className="text-right">
                <p className="text-sm font-medium text-gray-900">Alex Thompson</p>
                <p className="text-xs text-gray-500">Premium Plan</p>
              </div>
            </div>
          </div>
        </div>
      </header>

      {/* Main Content */}
      <main className="p-8">
        {/* Welcome Message */}
        <div className="mb-8">
          <h1 className="text-2xl font-bold text-gray-900">Welcome back, Alex 👋</h1>
          <p className="text-gray-600 mt-1">Here's what's happening with your finances today.</p>
        </div>

        {/* Financial Overview */}
        <div className="grid grid-cols-3 gap-6 mb-8">
          <div className="bg-white p-6 rounded-2xl shadow-sm border border-gray-100 hover:shadow-md transition-shadow">
            <div className="flex items-center justify-between mb-4">
              <h3 className="text-gray-500 font-medium">Total Balance</h3>
              <div className="w-10 h-10 rounded-full bg-indigo-50 flex items-center justify-center">
                <DollarSign className="w-5 h-5 text-indigo-600" />
              </div>
            </div>
            <p className="text-3xl font-bold text-gray-900">$24,563.82</p>
            <div className="flex items-center gap-2 mt-2 text-green-600 bg-green-50 px-2 py-1 rounded-full w-fit">
              <ArrowUpRight className="w-4 h-4" />
              <span className="text-sm font-medium">+2.45%</span>
            </div>
          </div>

          <div className="bg-white p-6 rounded-2xl shadow-sm border border-gray-100 hover:shadow-md transition-shadow">
            <div className="flex items-center justify-between mb-4">
              <h3 className="text-gray-500 font-medium">Monthly Spending</h3>
              <div className="w-10 h-10 rounded-full bg-purple-50 flex items-center justify-center">
                <CreditCard className="w-5 h-5 text-purple-600" />
              </div>
            </div>
            <p className="text-3xl font-bold text-gray-900">$3,246.12</p>
            <div className="flex items-center gap-2 mt-2 text-red-600 bg-red-50 px-2 py-1 rounded-full w-fit">
              <ArrowDownRight className="w-4 h-4" />
              <span className="text-sm font-medium">-4.75%</span>
            </div>
          </div>

          <div className="bg-gradient-to-br from-indigo-600 to-indigo-800 p-6 rounded-2xl shadow-lg text-white relative overflow-hidden">
            <div className="absolute top-0 right-0 w-32 h-32 bg-white/10 rounded-full transform translate-x-16 -translate-y-16"></div>
            <div className="absolute bottom-0 left-0 w-24 h-24 bg-white/10 rounded-full transform -translate-x-12 translate-y-12"></div>
            
            <div className="relative">
              <div className="flex items-center gap-2 mb-4">
                <Sparkles className="w-5 h-5" />
                <h3 className="font-medium">AI Insights</h3>
              </div>
              <p className="text-sm opacity-90 mb-4 leading-relaxed">
                Based on your spending patterns, you could save an additional $427 this month
                by optimizing your subscription services.
              </p>
              <button className="px-4 py-2 bg-white/10 rounded-lg text-sm hover:bg-white/20 transition-colors inline-flex items-center gap-2">
                View Details
                <ArrowUpRight className="w-4 h-4" />
              </button>
            </div>
          </div>
        </div>

        {/* Goals Progress */}
        <div className="bg-white rounded-2xl shadow-sm border border-gray-100 p-6 mb-8">
          <div className="flex items-center justify-between mb-6">
            <div>
              <h2 className="text-xl font-bold text-gray-900">Financial Goals</h2>
              <p className="text-sm text-gray-500 mt-1">Track your progress towards your goals</p>
            </div>
            <button className="px-4 py-2 text-sm font-medium text-indigo-600 hover:bg-indigo-50 rounded-lg transition-colors">
              Add New Goal
            </button>
          </div>
          
          <div className="grid grid-cols-3 gap-6">
            {[
              { name: 'Emergency Fund', current: 8400, target: 10000, color: 'bg-emerald-500' },
              { name: 'New Car', current: 12000, target: 35000, color: 'bg-blue-500' },
              { name: 'Vacation', current: 2800, target: 5000, color: 'bg-purple-500' },
            ].map((goal) => (
              <div key={goal.name} className="p-4 rounded-xl bg-gray-50">
                <div className="flex items-center justify-between mb-3">
                  <h3 className="font-medium text-gray-900">{goal.name}</h3>
                  <Target className="w-5 h-5 text-gray-400" />
                </div>
                <div className="mb-2 h-2 bg-gray-200 rounded-full overflow-hidden">
                  <div 
                    className={`h-full ${goal.color} transition-all duration-500`}
                    style={{ width: `${(goal.current / goal.target) * 100}%` }}
                  ></div>
                </div>
                <div className="flex items-center justify-between text-sm">
                  <span className="text-gray-500">${goal.current.toLocaleString()}</span>
                  <span className="text-gray-900 font-medium">${goal.target.toLocaleString()}</span>
                </div>
              </div>
            ))}
          </div>
        </div>

        {/* Recent Transactions */}
        <div className="bg-white rounded-2xl shadow-sm border border-gray-100 p-6">
          <div className="flex items-center justify-between mb-6">
            <div>
              <h2 className="text-xl font-bold text-gray-900">Recent Transactions</h2>
              <p className="text-sm text-gray-500 mt-1">Your latest financial activities</p>
            </div>
            <button className="px-4 py-2 text-sm font-medium text-indigo-600 hover:bg-indigo-50 rounded-lg transition-colors">
              View All
            </button>
          </div>
          
          <div className="space-y-4">
            {[
              {
                name: 'Netflix Subscription',
                category: 'Entertainment',
                amount: -14.99,
                date: 'Today',
                icon: '🎬',
              },
              {
                name: 'Salary Deposit',
                category: 'Income',
                amount: 5240.00,
                date: 'Yesterday',
                icon: '💰',
              },
              {
                name: 'Whole Foods Market',
                category: 'Groceries',
                amount: -89.43,
                date: 'Yesterday',
                icon: '🛒',
              },
            ].map((transaction) => (
              <div
                key={transaction.name}
                className="flex items-center justify-between p-4 rounded-xl hover:bg-gray-50 transition-colors cursor-pointer"
              >
                <div className="flex items-center gap-4">
                  <div className={`w-12 h-12 rounded-xl flex items-center justify-center text-xl
                    ${transaction.amount > 0 ? 'bg-green-100' : 'bg-gray-100'}`}>
                    {transaction.icon}
                  </div>
                  <div>
                    <p className="font-medium text-gray-900">{transaction.name}</p>
                    <p className="text-sm text-gray-500">{transaction.category}</p>
                  </div>
                </div>
                <div className="text-right">
                  <p className={`font-medium ${
                    transaction.amount > 0 ? 'text-green-600' : 'text-gray-900'
                  }`}>
                    {transaction.amount > 0 ? '+' : ''}
                    ${Math.abs(transaction.amount).toFixed(2)}
                  </p>
                  <p className="text-sm text-gray-500">{transaction.date}</p>
                </div>
              </div>
            ))}
          </div>
        </div>
      </main>
    </div>
  );
};

export default Dashboard;